const express = require("express");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const { v4: uuidv4 } = require("uuid");

const app = express();
const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, "data");
const UPLOAD_DIR = path.join(ROOT, "uploads");
const DB_FILE = path.join(DATA_DIR, "surprises.json");

fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(UPLOAD_DIR, { recursive: true });
if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, "[]");

const readDB = () => JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
const writeDB = (data) => fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));

const storage = multer.diskStorage({
  destination: (_, __, cb) => cb(null, UPLOAD_DIR),
  filename: (_, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, uuidv4() + ext);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 8 * 1024 * 1024, files: 8 },
  fileFilter: (_, file, cb) => {
    if (/^image\/(jpeg|png|webp|gif)$/.test(file.mimetype)) cb(null, true);
    else cb(new Error("Only JPG, PNG, WEBP and GIF images are allowed."));
  }
});

app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true }));
app.use("/uploads", express.static(UPLOAD_DIR));
app.use(express.static(path.join(ROOT, "public")));

app.post("/api/surprises", upload.array("photos", 8), (req, res) => {
  try {
    const {
      recipient = "My Love",
      sender = "Someone who loves you",
      date = "",
      message = "",
      theme = "rose",
      cake = "rose"
    } = req.body;

    const clean = (v, max) => String(v).trim().slice(0, max);
    const slug = uuidv4().replace(/-/g, "").slice(0, 10);

    const item = {
      id: uuidv4(),
      slug,
      recipient: clean(recipient, 60) || "My Love",
      sender: clean(sender, 60) || "Someone who loves you",
      date: clean(date, 30),
      message: clean(message, 2000),
      theme: clean(theme, 20),
      cake: clean(cake, 20),
      photos: (req.files || []).map(f => `/uploads/${f.filename}`),
      createdAt: new Date().toISOString()
    };

    const db = readDB();
    db.push(item);
    writeDB(db);

    const base = `${req.protocol}://${req.get("host")}`;
    res.json({ ok: true, slug, url: `${base}/s/${slug}` });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.get("/api/surprises/:slug", (req, res) => {
  const item = readDB().find(x => x.slug === req.params.slug);
  if (!item) return res.status(404).json({ ok: false, error: "Surprise not found." });
  res.json({ ok: true, surprise: item });
});

app.get("/s/:slug", (_, res) => {
  res.sendFile(path.join(ROOT, "public", "surprise.html"));
});

app.get("*", (_, res) => {
  res.sendFile(path.join(ROOT, "public", "index.html"));
});

app.use((err, _, res, __) => {
  res.status(400).json({ ok: false, error: err.message || "Upload failed." });
});

app.listen(PORT, () => {
  console.log(`Lovely Surprise running at http://localhost:${PORT}`);
});