const panels = [...document.querySelectorAll(".panel")];
const steps = [...document.querySelectorAll(".step")];
let current = 1;
let theme = "rose";
let cake = "rose";

const $ = id => document.getElementById(id);

function show(n) {
  current = n;
  panels.forEach(p => p.classList.toggle("active", +p.dataset.panel === n));
  steps.forEach(s => s.classList.toggle("active", +s.dataset.step <= n));
  window.scrollTo({top: 0, behavior: "smooth"});
  if (n === 4) buildSummary();
}
document.querySelectorAll(".next").forEach(b => b.onclick = () => {
  if (current === 1 && !$("recipient").value.trim()) {
    $("recipient").focus(); return;
  }
  show(Math.min(4, current + 1));
});
document.querySelectorAll(".back").forEach(b => b.onclick = () => show(Math.max(1, current - 1)));

document.querySelectorAll("[data-theme]").forEach(b => b.onclick = () => {
  document.querySelectorAll("[data-theme]").forEach(x => x.classList.remove("selected"));
  b.classList.add("selected"); theme = b.dataset.theme;
});
document.querySelectorAll("[data-cake]").forEach(b => b.onclick = () => {
  document.querySelectorAll("[data-cake]").forEach(x => x.classList.remove("selected"));
  b.classList.add("selected"); cake = b.dataset.cake;
});

$("photos").onchange = () => {
  const files = [...$("photos").files];
  $("photoPreview").innerHTML = "";
  files.forEach(file => {
    const img = document.createElement("img");
    img.src = URL.createObjectURL(file);
    $("photoPreview").appendChild(img);
  });
};

function buildSummary() {
  const name = $("recipient").value || "My Love";
  const sender = $("sender").value || "Someone who loves you";
  const photos = $("photos").files.length;
  $("summary").innerHTML = `
    <div><span>For</span><b>${escapeHtml(name)}</b></div>
    <div><span>From</span><b>${escapeHtml(sender)}</b></div>
    <div><span>Memories</span><b>${photos} photo${photos === 1 ? "" : "s"}</b></div>
    <div><span>Style</span><b>${themeLabel(theme)} • ${cakeLabel(cake)}</b></div>`;
}
function themeLabel(x){return ({rose:"Rose Glow",midnight:"Midnight Love",sunset:"Golden Sunset"})[x]}
function cakeLabel(x){return ({rose:"Rose Cake",chocolate:"Chocolate",strawberry:"Strawberry"})[x]}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}

$("creatorForm").onsubmit = async e => {
  e.preventDefault();
  const btn = e.submitter;
  btn.disabled = true; btn.textContent = "Creating magic…";
  const fd = new FormData();
  fd.append("recipient", $("recipient").value);
  fd.append("sender", $("sender").value);
  fd.append("date", $("date").value);
  fd.append("message", $("message").value);
  fd.append("theme", theme);
  fd.append("cake", cake);
  [...$("photos").files].forEach(f => fd.append("photos", f));
  try {
    const r = await fetch("/api/surprises", {method:"POST", body:fd});
    const data = await r.json();
    if (!r.ok) throw new Error(data.error || "Could not create surprise.");
    $("shareUrl").value = data.url;
    $("wa").href = `https://wa.me/?text=${encodeURIComponent("I made a little surprise for you ♥ " + data.url)}`;
    $("openBtn").onclick = () => location.href = data.url;
    $("modal").classList.remove("hidden");
  } catch(err) { alert(err.message); }
  finally { btn.disabled = false; btn.textContent = "Create My Surprise ✨"; }
};

$("copyBtn").onclick = async () => {
  await navigator.clipboard.writeText($("shareUrl").value);
  $("copyBtn").textContent = "Copied ✓";
  setTimeout(() => $("copyBtn").textContent = "Copy", 1500);
};