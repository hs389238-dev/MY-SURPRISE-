const slug = location.pathname.split("/").filter(Boolean).pop();
const $ = id => document.getElementById(id);
let data;

async function load() {
  const r = await fetch("/api/surprises/" + slug);
  const j = await r.json();
  if (!r.ok) { document.body.innerHTML = "<main class='error'>This surprise link is no longer available.</main>"; return; }
  data = j.surprise;
  document.body.className = "reveal " + (data.theme || "rose");
  $("recipient").textContent = data.recipient;
  $("letterName").textContent = data.recipient;
  $("finalName").textContent = data.recipient;
  $("sender").textContent = data.sender;
  $("message").textContent = data.message || `I hope this little surprise makes you smile. You deserve so many beautiful moments, today and always. Happy Birthday, ${data.recipient}! ♥`;
  if (data.date) $("dateLine").textContent = new Date(data.date + "T00:00:00").toLocaleDateString(undefined,{day:"numeric",month:"long",year:"numeric"});
  const cakeMap = {rose:"🍰",chocolate:"🎂",strawberry:"🍓"};
  $("cake").textContent = cakeMap[data.cake] || "🎂";
  const gallery = $("gallery");
  if (data.photos.length) data.photos.forEach((src,i) => {
    const figure = document.createElement("figure");
    figure.style.setProperty("--d", `${i*80}ms`);
    figure.innerHTML = `<img src="${src}" alt="Memory ${i+1}">`;
    gallery.appendChild(figure);
  });
  else gallery.innerHTML = `<div class="no-photos">No photos were added — but the memories are still here. ♥</div>`;
}
function show(id) {
  document.querySelectorAll(".reveal-screen,.story").forEach(x=>x.classList.add("hidden"));
  $(id).classList.remove("hidden");
  window.scrollTo({top:0,behavior:"smooth"});
  burstHearts(18);
}
function burstHearts(n=12) {
  const holder=$("hearts");
  for(let i=0;i<n;i++){
    const h=document.createElement("span"); h.textContent=Math.random()>.5?"♥":"♡";
    h.style.left=Math.random()*100+"vw"; h.style.animationDelay=Math.random()*.4+"s";
    h.style.setProperty("--x",(Math.random()-.5)*180+"px");
    holder.appendChild(h); setTimeout(()=>h.remove(),2600);
  }
}
$("enter").onclick=()=>show("story");
$("memoriesBtn").onclick=()=>show("memories");
$("letterBtn").onclick=()=>show("letter");
$("finalBtn").onclick=()=>{show("final"); burstHearts(40);};
load();