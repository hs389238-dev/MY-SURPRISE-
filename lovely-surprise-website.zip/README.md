# Lovely Surprise

A romantic birthday-surprise website with a free share-link flow.

## Run locally
1. Install Node.js 18+.
2. Open a terminal in this folder.
3. Run `npm install`
4. Run `npm start`
5. Open `http://localhost:3000`

## What it does
- Create a surprise with name, date, message, theme and up to 8 photos.
- Stores surprise data on the server.
- Generates a unique URL such as `/s/abc123`.
- The recipient can open that URL on another device.
- No payment step is included.

## Production notes
This starter uses a local JSON database and local uploads, which is convenient for a small personal deployment. For a production-scale public service, replace them with a persistent database/object storage (for example PostgreSQL + S3-compatible storage) and add authentication, rate limiting, moderation, backups and upload scanning.

## Deploy
You can deploy the Node app to a host that supports Express/Node. Set `PORT` if your host requires it. For a persistent public site, use persistent storage for `data/surprises.json` and `uploads/`, or change the storage layer as described above.
